/*
Navicat MySQL Data Transfer

Source Server         : MySQL
Source Server Version : 50505
Source Host           : 127.0.0.1:3306
Source Database       : dbphp7

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2017-02-24 21:36:27
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for modal
-- ----------------------------
DROP TABLE IF EXISTS `modal`;
CREATE TABLE `modal` (
  `modal_id` int(11) NOT NULL AUTO_INCREMENT,
  `modal_name` varchar(255) DEFAULT NULL,
  `description` text,
  `date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`modal_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of modal
-- ----------------------------
INSERT INTO `modal` VALUES ('10', 'Aguzrybudy', 'Web Developer in Alterxalter.com, and owner blog aguzrybudy.blogspot.co.id ', '2016-04-19 21:22:06');
INSERT INTO `modal` VALUES ('11', 'Ilmu yang tidak diamalkan', 'Ilmu yang tidak diamalkan bagai pohon yang tak berbuah', '2016-04-19 21:26:23');
INSERT INTO `modal` VALUES ('12', 'Berterima kasih pada allah', 'Berterima kasih pada allah yang telah memberikan ilmu pengetahuan kepada kita', '2016-04-19 21:41:22');
INSERT INTO `modal` VALUES ('13', 'Programmer', 'Programmer Calm', null);
INSERT INTO `modal` VALUES ('14', 'Web Developer', 'Web Developer', null);
INSERT INTO `modal` VALUES ('15', 'Informatika', 'Informatika', '2017-02-24 20:47:57');
INSERT INTO `modal` VALUES ('16', 'Ilmu komputer', 'ilmu komputer', null);
INSERT INTO `modal` VALUES ('17', 'Ilmu Jiwa', 'Ilmu jiwa', null);
INSERT INTO `modal` VALUES ('18', 'Softaware', 'software expired', null);
INSERT INTO `modal` VALUES ('19', 'Error Code', 'Code Error', null);
INSERT INTO `modal` VALUES ('20', 'Full Stack', 'Full stack', null);
INSERT INTO `modal` VALUES ('21', 'Happy coding', 'Happy coding', null);
INSERT INTO `modal` VALUES ('22', 'Keep Smile', 'Keep Smile', null);
INSERT INTO `modal` VALUES ('23', 'Fix Bug', 'Fix Bug', null);
INSERT INTO `modal` VALUES ('24', 'Framework', 'Framework', null);
INSERT INTO `modal` VALUES ('25', 'Codeigniter', 'Codeingiter', null);
INSERT INTO `modal` VALUES ('26', 'Laravel', 'Laravel', null);
INSERT INTO `modal` VALUES ('27', 'Yii', 'Yii', null);
INSERT INTO `modal` VALUES ('28', 'Lumen', 'Lumen', '2017-02-24 20:50:07');
INSERT INTO `modal` VALUES ('29', 'Android Studio', 'Android Studio', null);
